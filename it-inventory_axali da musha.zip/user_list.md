| Username | Password   | Role   |
|----------|------------|--------|
| admin    | adminpass  | admin  |
| it1      | itpass1    | it     |
| it2      | itpass2    | it     |
| it3      | itpass3    | it     |
| it4      | itpass4    | it     |
| it5      | itpass5    | it     |
| it6      | itpass6    | it     |
| it7      | itpass7    | it     |
| it8      | itpass8    | it     |
| it9      | itpass9    | it     |