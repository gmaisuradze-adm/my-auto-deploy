from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
from werkzeug.security import check_password_hash, generate_password_hash # generate_password_hash is for db_init.py
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24) # უფრო უსაფრთხო საიდუმლო გასაღები
DATABASE = 'inventory.db'
APP_VERSION = "1.0.0" # შეგიძლიათ განაახლოთ ვერსია

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# --- Decorators ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('გთხოვთ, გაიაროთ ავტორიზაცია.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('გთხოვთ, გაიაროთ ავტორიზაცია.', 'warning')
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('ამ გვერდზე წვდომა შეზღუდულია ადმინისტრატორისთვის.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def it_role_required(f): # ზოგადი IT როლისთვის (admin-საც შეუძლია)
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('გთხოვთ, გაიაროთ ავტორიზაცია.', 'warning')
            return redirect(url_for('login'))
        if session.get('role') not in ['admin', 'it']:
            flash('ამ ოპერაციისთვის საჭიროა IT ან ადმინისტრატორის როლი.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# --- AUTH ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('logged_in'):
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['logged_in'] = True
            session['username'] = user['username']
            session['user_id'] = user['id']
            session['role'] = user['role']
            flash('წარმატებული ავტორიზაცია!', 'success')
            return redirect(url_for('index'))
        else:
            flash('მომხმარებლის სახელი ან პაროლი არასწორია.', 'danger')
    return render_template('login.html', app_version=APP_VERSION)

@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('თქვენ გამოხვედით სისტემიდან.', 'info')
    return redirect(url_for('login'))

# --- DASHBOARD ---
@app.route('/')
@login_required
def index():
    conn = get_db_connection()
    inventory_count = conn.execute('SELECT COUNT(id) FROM inventory').fetchone()[0]
    requests_new_count = conn.execute('SELECT COUNT(id) FROM requests WHERE status = ?', ('ახალი',)).fetchone()[0]
    requests_assigned_count = conn.execute('SELECT COUNT(id) FROM requests WHERE status = ? AND assigned_to = ?', ('მიმდინარე', session['username'])).fetchone()[0]
    conn.close()
    return render_template('index.html',
                           inventory_count=inventory_count,
                           requests_new_count=requests_new_count,
                           requests_assigned_count=requests_assigned_count,
                           app_version=APP_VERSION)

# --- INVENTORY ---
@app.route('/inventory')
@login_required
def inventory_list():
    search_query = request.args.get('q', '')
    conn = get_db_connection()
    if search_query:
        items = conn.execute(
            "SELECT * FROM inventory WHERE type LIKE ? OR manufacturer LIKE ? OR model LIKE ? OR serial LIKE ? OR owner LIKE ? OR location LIKE ? ORDER BY id DESC",
            (f'%{search_query}%', f'%{search_query}%', f'%{search_query}%', f'%{search_query}%', f'%{search_query}%', f'%{search_query}%')
        ).fetchall()
    else:
        items = conn.execute('SELECT * FROM inventory ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('inventory_list.html', items=items, search_query=search_query, app_version=APP_VERSION)

@app.route('/inventory/add', methods=['GET', 'POST'])
@it_role_required
def inventory_add():
    if request.method == 'POST':
        data = {key: request.form[key] for key in ['type', 'manufacturer', 'model', 'serial', 'status', 'owner', 'install_date', 'location', 'description', 'comment']}
        conn = get_db_connection()
        try:
            cur = conn.cursor()
            cur.execute('INSERT INTO inventory (type, manufacturer, model, serial, status, owner, install_date, location, description, comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                         list(data.values()))
            inventory_id = cur.lastrowid
            conn.commit()
            # Log change
            conn.execute('INSERT INTO changes (inventory_id, field, old_value, new_value, comment, changed_by, change_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
                         (inventory_id, 'ALL', '', 'ახალი ჩანაწერი', 'ინვენტარის დამატება', session['username'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.commit()
            flash('ინვენტარი წარმატებით დაემატა.', 'success')
        except sqlite3.Error as e:
            flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
        finally:
            conn.close()
        return redirect(url_for('inventory_list'))
    return render_template('inventory_form.html', item=None, action_url=url_for('inventory_add'), form_title="ინვენტარის დამატება", app_version=APP_VERSION)

@app.route('/inventory/edit/<int:item_id>', methods=['GET', 'POST'])
@it_role_required
def inventory_edit(item_id):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM inventory WHERE id = ?', (item_id,)).fetchone()
    if not item:
        flash('ინვენტარი ვერ მოიძებნა.', 'danger')
        conn.close()
        return redirect(url_for('inventory_list'))

    if request.method == 'POST':
        new_data = {key: request.form[key] for key in ['type', 'manufacturer', 'model', 'serial', 'status', 'owner', 'install_date', 'location', 'description', 'comment']}
        fields_to_update = []
        params = []
        log_entries = []

        for key, new_value in new_data.items():
            old_value = item[key]
            if str(old_value) != str(new_value): # შედარება სტრიქონებად
                fields_to_update.append(f"{key} = ?")
                params.append(new_value)
                log_entries.append((item_id, key, old_value, new_value, request.form.get('change_comment', 'ინვენტარის განახლება'), session['username'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

        if fields_to_update:
            params.append(item_id)
            try:
                conn.execute(f"UPDATE inventory SET {', '.join(fields_to_update)} WHERE id = ?", tuple(params))
                for log_entry in log_entries:
                    conn.execute('INSERT INTO changes (inventory_id, field, old_value, new_value, comment, changed_by, change_date) VALUES (?, ?, ?, ?, ?, ?, ?)', log_entry)
                conn.commit()
                flash('ინვენტარი წარმატებით განახლდა.', 'success')
            except sqlite3.Error as e:
                flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
        else:
            flash('ცვლილებები არ დაფიქსირებულა.', 'info')
        conn.close()
        return redirect(url_for('inventory_view', item_id=item_id))

    conn.close()
    return render_template('inventory_form.html', item=item, action_url=url_for('inventory_edit', item_id=item_id), form_title="ინვენტარის რედაქტირება", app_version=APP_VERSION)

@app.route('/inventory/view/<int:item_id>')
@login_required
def inventory_view(item_id):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM inventory WHERE id = ?', (item_id,)).fetchone()
    if not item:
        flash('ინვენტარი ვერ მოიძებნა.', 'danger')
        conn.close()
        return redirect(url_for('inventory_list'))
    history = conn.execute('SELECT * FROM changes WHERE inventory_id = ? ORDER BY change_date DESC', (item_id,)).fetchall()
    conn.close()
    return render_template('inventory_view.html', item=item, history=history, app_version=APP_VERSION)

@app.route('/inventory/delete/<int:item_id>', methods=['POST'])
@admin_required # მხოლოდ ადმინს შეუძლია წაშლა
def inventory_delete(item_id):
    conn = get_db_connection()
    try:
        # Optional: Check if item is linked to requests, etc. before deleting
        conn.execute('DELETE FROM changes WHERE inventory_id = ?', (item_id,)) # წაშალე ისტორიაც
        conn.execute('DELETE FROM inventory WHERE id = ?', (item_id,))
        conn.commit()
        flash('ინვენტარი წარმატებით წაიშალა.', 'success')
    except sqlite3.Error as e:
        flash(f'წაშლისას დაფიქსირდა შეცდომა: {e}', 'danger')
    finally:
        conn.close()
    return redirect(url_for('inventory_list'))

# --- REQUESTS ---
@app.route('/requests')
@login_required
def requests_list():
    # ფილტრაცია სტატუსის და მიკუთვნების მიხედვით
    status_filter = request.args.get('status', 'all') # all, ახალი, მიმდინარე, შესრულებული, უარყოფილი
    assignee_filter = request.args.get('assignee', 'all') # all, me, unassigned

    conn = get_db_connection()
    query = "SELECT r.*, u.username as assigned_username FROM requests r LEFT JOIN users u ON r.assigned_to = u.id WHERE 1=1"
    params = []

    if status_filter != 'all':
        query += " AND r.status = ?"
        params.append(status_filter)

    if assignee_filter == 'me' and session.get('role') == 'it':
        query += " AND r.assigned_to = ?"
        params.append(session['user_id']) # იუზერის ID-თი ვფილტრავთ
    elif assignee_filter == 'unassigned':
         query += " AND r.assigned_to IS NULL"


    query += " ORDER BY r.created_at DESC"
    items = conn.execute(query, tuple(params)).fetchall()
    conn.close()
    return render_template('requests_list.html',
                           requests=items,
                           app_version=APP_VERSION,
                           status_filter=status_filter,
                           assignee_filter=assignee_filter)

@app.route('/requests/add', methods=['GET', 'POST'])
@it_role_required # ნებისმიერ IT-ს ან ადმინს შეუძლია მოთხოვნის დამატება
def request_add():
    if request.method == 'POST':
        data = {key: request.form[key] for key in ['type', 'quantity', 'description', 'reason', 'location']}
        requested_by = session['username'] # მომთხოვნი არის მიმდინარე მომხმარებელი
        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        status = 'ახალი' # საწყისი სტატუსი
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO requests (type, quantity, description, reason, location, requested_by, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                         (data['type'], data.get('quantity', 1), data['description'], data['reason'], data['location'], requested_by, status, created_at))
            conn.commit()
            flash('მოთხოვნა წარმატებით დაემატა.', 'success')
        except sqlite3.Error as e:
            flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
        finally:
            conn.close()
        return redirect(url_for('requests_list'))
    return render_template('request_form.html', req=None, action_url=url_for('request_add'), form_title="ახალი მოთხოვნა", app_version=APP_VERSION)

@app.route('/requests/view/<int:req_id>')
@login_required
def request_view(req_id):
    conn = get_db_connection()
    req = conn.execute('SELECT r.*, u_assigned.username as assigned_username FROM requests r LEFT JOIN users u_assigned ON r.assigned_to = u_assigned.id WHERE r.id = ?', (req_id,)).fetchone()
    if not req:
        flash('მოთხოვნა ვერ მოიძებნა.', 'danger')
        conn.close()
        return redirect(url_for('requests_list'))

    # ინვენტარის სია, რომელიც შეიძლება დაუკავშირდეს მოთხოვნას
    inventory_items = conn.execute('SELECT id, type, model, serial FROM inventory ORDER BY type, model').fetchall()
    conn.close()
    return render_template('request_view.html', req=req, inventory_items=inventory_items, app_version=APP_VERSION)

@app.route('/requests/assign/<int:req_id>', methods=['POST'])
@it_role_required
def request_assign(req_id):
    conn = get_db_connection()
    req = conn.execute('SELECT * FROM requests WHERE id = ?', (req_id,)).fetchone()
    if not req:
        flash('მოთხოვნა ვერ მოიძებნა.', 'danger')
    elif req['status'] != 'ახალი':
        flash('ამ მოთხოვნის მიკუთვნება შეუძლებელია (სტატუსი არ არის "ახალი").', 'warning')
    else:
        try:
            conn.execute('UPDATE requests SET assigned_to = ?, status = ? WHERE id = ?',
                         (session['user_id'], 'მიმდინარე', req_id))
            conn.commit()
            flash(f'მოთხოვნა #{req_id} მიეკუთვნა თქვენ.', 'success')
        except sqlite3.Error as e:
            flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
    conn.close()
    return redirect(url_for('request_view', req_id=req_id))

@app.route('/requests/update_status/<int:req_id>', methods=['POST'])
@it_role_required
def request_update_status(req_id):
    conn = get_db_connection()
    req = conn.execute('SELECT * FROM requests WHERE id = ?', (req_id,)).fetchone()
    if not req:
        flash('მოთხოვნა ვერ მოიძებნა.', 'danger')
        conn.close()
        return redirect(url_for('requests_list'))

    # დარწმუნდი, რომ მომხმარებელია მიკუთვნებული ან არის ადმინი
    if req['assigned_to'] != session['user_id'] and session['role'] != 'admin':
        flash('თქვენ არ შეგიძლიათ ამ მოთხოვნის სტატუსის განახლება.', 'danger')
        conn.close()
        return redirect(url_for('request_view', req_id=req_id))

    new_status = request.form.get('status')
    response_text = request.form.get('response', req['response']) # შეინახე ძველი თუ ახალი არ მოვიდა
    linked_inventory_id = request.form.get('inventory_id', req['inventory_id'])
    if linked_inventory_id == "": linked_inventory_id = None


    if new_status not in ['შესრულებული', 'უარყოფილი']:
        flash('არასწორი სტატუსი.', 'warning')
        conn.close()
        return redirect(url_for('request_view', req_id=req_id))

    try:
        update_fields = {'status': new_status, 'response': response_text}
        if new_status == 'შესრულებული':
            update_fields['install_date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if linked_inventory_id:
             update_fields['inventory_id'] = linked_inventory_id


        query_parts = [f"{key} = ?" for key in update_fields.keys()]
        values = list(update_fields.values())
        values.append(req_id)

        conn.execute(f"UPDATE requests SET {', '.join(query_parts)} WHERE id = ?", tuple(values))
        conn.commit()

        # თუ "შესრულებულია" და ინვენტარი არ არის დაკავშირებული, მაგრამ მოთხოვნა გულისხმობს ახალ ნივთს
        if new_status == 'შესრულებული' and not linked_inventory_id and req['type'] not in ['მომსახურება', 'კონსულტაცია', 'შეკეთება']:
             # ავტომატურად დაამატე ინვენტარი, თუ მოთხოვნა ამას გულისხმობს
            new_inv_comment = f"ავტომატურად დამატებულია მოთხოვნის #{req_id} საფუძველზე."
            cur = conn.cursor()
            cur.execute('INSERT INTO inventory (type, status, owner, install_date, location, description, comment) VALUES (?, ?, ?, ?, ?, ?, ?)',
                         (req['type'], 'აქტიური', req['requested_by'], update_fields['install_date'], req['location'], req['description'], new_inv_comment))
            new_inventory_id = cur.lastrowid
            conn.execute('UPDATE requests SET inventory_id = ? WHERE id = ?', (new_inventory_id, req_id))

            # Log change for new inventory
            conn.execute('INSERT INTO changes (inventory_id, field, old_value, new_value, comment, changed_by, change_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
                         (new_inventory_id, 'ALL', '', 'ახალი ჩანაწერი', new_inv_comment, session['username'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.commit()
            flash(f'მოთხოვნა #{req_id} განახლდა და ახალი ინვენტარი #{new_inventory_id} დაემატა.', 'success')
        else:
            flash(f'მოთხოვნის #{req_id} სტატუსი განახლდა: {new_status}.', 'success')

    except sqlite3.Error as e:
        flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
    finally:
        conn.close()
    return redirect(url_for('request_view', req_id=req_id))


# --- USERS (Admin only) ---
@app.route('/users')
@admin_required
def users_list():
    conn = get_db_connection()
    users = conn.execute('SELECT id, username, role FROM users ORDER BY username').fetchall()
    conn.close()
    return render_template('users_list.html', users=users, app_version=APP_VERSION)

@app.route('/users/add', methods=['GET', 'POST'])
@admin_required
def user_add():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        if not username or not password or not role:
            flash('ყველა ველი სავალდებულოა.', 'danger')
            return render_template('user_form.html', user=None, action_url=url_for('user_add'), form_title="მომხმარებლის დამატება", app_version=APP_VERSION)

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                         (username, hashed_password, role))
            conn.commit()
            flash('მომხმარებელი წარმატებით დაემატა.', 'success')
        except sqlite3.IntegrityError:
            flash('მომხმარებელი ასეთი სახელით უკვე არსებობს.', 'danger')
        except sqlite3.Error as e:
            flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
        finally:
            conn.close()
        return redirect(url_for('users_list'))
    return render_template('user_form.html', user=None, action_url=url_for('user_add'), form_title="მომხმარებლის დამატება", app_version=APP_VERSION)

@app.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def user_edit(user_id):
    conn = get_db_connection()
    user = conn.execute('SELECT id, username, role FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        flash('მომხმარებელი ვერ მოიძებნა.', 'danger')
        conn.close()
        return redirect(url_for('users_list'))

    if request.method == 'POST':
        new_username = request.form['username']
        new_password = request.form['password'] # პაროლი არასავალდებულოა რედაქტირებისას
        new_role = request.form['role']

        if not new_username or not new_role:
            flash('მომხმარებლის სახელი და როლი სავალდებულოა.', 'danger')
            conn.close()
            return render_template('user_form.html', user=user, action_url=url_for('user_edit', user_id=user_id), form_title="მომხმარებლის რედაქტირება", app_version=APP_VERSION)

        update_fields = {'username': new_username, 'role': new_role}
        if new_password: # თუ პაროლი შეყვანილია, განაახლე
            update_fields['password'] = generate_password_hash(new_password)

        query_parts = [f"{key} = ?" for key in update_fields.keys()]
        values = list(update_fields.values())
        values.append(user_id)

        try:
            conn.execute(f"UPDATE users SET {', '.join(query_parts)} WHERE id = ?", tuple(values))
            conn.commit()
            flash('მომხმარებელი წარმატებით განახლდა.', 'success')
        except sqlite3.IntegrityError:
            flash('მომხმარებელი ასეთი სახელით უკვე არსებობს (სხვა იუზერს უკავია).', 'danger')
        except sqlite3.Error as e:
            flash(f'დაფიქსირდა შეცდომა: {e}', 'danger')
        finally:
            conn.close()
        return redirect(url_for('users_list'))

    conn.close()
    return render_template('user_form.html', user=user, action_url=url_for('user_edit', user_id=user_id), form_title="მომხმარებლის რედაქტირება", app_version=APP_VERSION)

@app.route('/users/delete/<int:user_id>', methods=['POST'])
@admin_required
def user_delete(user_id):
    if session['user_id'] == user_id: # საკუთარი თავის წაშლის აკრძალვა
        flash('საკუთარი ანგარიშის წაშლა შეუძლებელია.', 'danger')
        return redirect(url_for('users_list'))
    conn = get_db_connection()
    try:
        # Optional: check if user is assigned to requests, etc.
        conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
        flash('მომხმარებელი წარმატებით წაიშალა.', 'success')
    except sqlite3.Error as e:
        flash(f'წაშლისას დაფიქსირდა შეცდომა: {e}', 'danger')
    finally:
        conn.close()
    return redirect(url_for('users_list'))


if __name__ == "__main__":
    if not os.path.exists(DATABASE):
        print(f"მონაცემთა ბაზა '{DATABASE}' არ არსებობს. გთხოვთ, პირველად გაუშვათ 'python db_init.py' მის შესაქმნელად.")
    else:
        app.run(debug=True, host='0.0.0.0', port=5000)