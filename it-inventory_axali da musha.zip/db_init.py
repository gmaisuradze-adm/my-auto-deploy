import sqlite3
from werkzeug.security import generate_password_hash

DATABASE = 'inventory.db'

USERS = [
    ('admin', 'adminpass', 'admin'),
    ('it1', 'itpass1', 'it'),
    ('it2', 'itpass2', 'it'),
    ('it3', 'itpass3', 'it'),
    ('it4', 'itpass4', 'it'),
    ('it5', 'itpass5', 'it'),
    ('it6', 'itpass6', 'it'),
    ('it7', 'itpass7', 'it'),
    ('it8', 'itpass8', 'it'),
    ('it9', 'itpass9', 'it'),
]

def main():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()

    # Drop tables for a clean start (remove in prod!)
    c.execute('DROP TABLE IF EXISTS users')
    c.execute('DROP TABLE IF EXISTS inventory')
    c.execute('DROP TABLE IF EXISTS changes')
    c.execute('DROP TABLE IF EXISTS requests')

    # Create tables
    with open('schema.sql', encoding='utf8') as f:
        c.executescript(f.read())

    for username, password, role in USERS:
        hash_pw = generate_password_hash(password)
        c.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', (username, hash_pw, role))
    conn.commit()
    conn.close()
    print("ბაზა და მომხმარებლები წარმატებით ინიციალიზდა!")

if __name__ == '__main__':
    main()