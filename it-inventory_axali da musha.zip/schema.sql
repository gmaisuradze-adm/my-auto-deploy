-- მომხმარებლები
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'it'))
);

-- ინვენტარი
CREATE TABLE inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    manufacturer TEXT,
    model TEXT,
    serial TEXT,
    status TEXT,
    owner TEXT,
    install_date TEXT,
    location TEXT,
    description TEXT,
    comment TEXT
);

-- ინვენტარის ცვლილებების ლოგი
CREATE TABLE changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inventory_id INTEGER,
    field TEXT,
    old_value TEXT,
    new_value TEXT,
    comment TEXT,
    changed_by TEXT,
    change_date TEXT
);

-- მოთხოვნები
CREATE TABLE requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    quantity INTEGER,
    description TEXT,
    reason TEXT,
    location TEXT,
    requested_by TEXT,
    status TEXT NOT NULL,
    assigned_to TEXT,
    response TEXT,
    install_date TEXT,
    inventory_id INTEGER,
    created_at TEXT
);